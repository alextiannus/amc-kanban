# Persistent Agent application starter

This is application-owned glue over the existing Core Runtime and resource modules. It supplies a configurable persistent working subject with scoped Memory, Workspace, selected Skills, sourced Knowledge, Session links, independent model settings and platform allowance accounting. It has no UI or mandatory role taxonomy. It does not copy an external companion framework.

## TypeScript starter contract

Import `openApplication`, `ApplicationOptions` and `Application` from
`@immedi/iaic-core/developer/templates/agent/app.mjs`. The adjacent `app.d.mts`
supports strict NodeNext and is also copied by the Agent scaffolder. It declares
ordinary system-profile configuration, custom metered model factories, job/tool
selection, current authorization, independent outcome verification, Host context,
Capability injection, Task admission/read/continuation/drain, scoped allowance
grants and settlement inspection. The structural database port accepts `pg.Pool`.
No root ambient declaration or implicit `any` is required.

`Application<A>` uses rich `A` only for explicit `hostContext.restoreActor`.
The `authorize` and outcome callbacks receive the minimal Core Actor, because
business identity is not persisted/restored by Runtime. Define extra Capabilities
against CoreActor and restore business identity using their Task ID, including in
history `revalidate`. Every function result used in later history needs current
revalidation; these declarations do not enforce that entire application policy.

This is a **basic composition contract**, not full declarations for every returned
module. Raw resource handles are `unknown`, not callable `any`. Optional scheduling,
events, Mandates, routing, release-binding and legacy user-model extension options
are not yet declared here; their existing JavaScript module compositions remain
available. Extend those module contracts separately when needed. Core root and full
Agent/Task/Peer declarations remain open. No runtime behavior or database migration
changes in candidate.101.

`examples/core-types-consumer/starter.mts` compiles and executes this public entry
from an independently installed tarball against isolated PostgreSQL. It verifies
Task wait, process-composition rebuild, continuation, explicit Actor restoration,
revocation, current history revalidation, one synthetic write and settled allowance.
This is not a real Provider or production business acceptance test.

Install with `npm install --ignore-scripts`. Set an isolated `SUBMISSION_TEST_DATABASE_URL` and run `npm test`. The test submits work, closes its Session, changes the default model, stops the initial Runtime, then runs queued work in a separate Node process. It confirms original model binding, existing resources, artifact references, scoped access and allowance settlement, plus pause on zero allowance and resume after explicit funding. `fixture-model.mjs` is only for this deterministic test; the real server never imports it. This is process-separated queued-work recovery, not a kill during a remote write or real-model quality acceptance.

For actual use, set DATABASE_URL, APP_TOKEN, APP_SUBJECT, APP_ORGANIZATION, IAIC_MODEL and AI_API_KEY. Optionally set IAIC_PROVIDER=chat-completions and IAIC_MODEL_BASE_URL to a compatible HTTPS base endpoint. Run `npm start`; it binds loopback port 3000 by default. Replace the single-user token mapping in server.mjs with application authentication and current organization membership checks before wider use.

The model defaults to the configured system profile. No platform allowance is granted automatically. A trusted local operator can explicitly run `npm run grant -- 1000000 UNIQUE_REFERENCE`; these are platform-issued units, not currency or literal provider Token credits. Model calls reserve and settle through the existing ledger and stop when allowance is insufficient. `config.mjs` contains starter allowance rates that the application owns. `openApplication` also accepts the existing userModels port for BYOK; no separate model or billing engine is introduced.

Call `agent.work` through `/capabilities/agent.work` with a stable requestKey and input containing goal, requiredArtifacts and an explicit allowedTools subset from job.json. Query `/capabilities/tasks.get` with `{id}` use tasks.cancel for cancellation, and tasks.resume after restoring allowance or resolving another resumable wait. An input-required wait still requires the existing host Runtime input flow. Direct resource tools use the same authorized dispatcher. The SDK exposes models, memory, sessions and knowledge modules for host integrations; there is no generic UI or public allowance-grant endpoint.

Edit job.json for responsibility, selected Skills, Knowledge IDs and available tools. Knowledge content and user memory remain in their existing stores; this starter does not invent source records. The host may populate them through app.knowledgeStore/app.memory with its own authorization. The default runtime revision hashes app/config/server code, job configuration, selected Skill files and the pinned Core archive at startup; changed executable resources cannot silently resume an old binding. Applications adding other executable resources must include them in this revision or bind their evaluated release manifest. Default resource scope distinguishes organization plus user and job; sharing is an explicit application policy.

The example verifier checks artifact and tool evidence. Replace config.mjs verifyOutcome with independent checks for the application's actual goal; do not treat this fixture as semantic certification. Optional scheduling, events and Mandates are described below. Handoffs, provider-specific deployment, webhook adapters and richer model-management endpoints use separate existing module compositions. Graceful shutdown closes the shared Runtime; database pool ownership remains with the host composition.

## Optional gateway composition

`openApplication` accepts optional `routing: {resolvePolicy, availability}` and returns `app.modelRouting` (null by default). These are the existing AssistantModelRouting ports: provide current authorized ordered profile IDs with a policy revision, plus trusted availability signals. The first route must match the selected profile for new Tasks. All alternatives use the same credential mode. Old Tasks resolve only their original model; changing health/default preference cannot silently replace it. Keep current application checks in the policy. No automatic routing policy is inferred from environment or model output.

For shared provider capacity/rates, initialize PostgresModelCapacity and PostgresModelRateLimits in host code before openApplication. Use the existing modelFactory port:

```js
import {createModelProvider, rateLimitedModel, capacityModel} from '@immedi/iaic-core';
const app = await openApplication({
  ...applicationOptions,
  routing: {resolvePolicy, availability},
  modelFactory: config => rateLimitedModel({
    model: capacityModel({model: createModelProvider(config), capacity}),
    rates,
    maximumTokens: request => trustedTokenUpperBound(request),
  }),
});
```

Here capacity/rates are already initialized stores for the correct provider account. For multiple accounts/deployments, select their own stores in the factory. The app still owns pool lifetime and all credentials/configuration. AssistantModels applies the original per-profile ledger wrapper outside these providers; do not wrap another metered gateway inside modelFactory. No allowance is issued automatically, and BYOK behavior remains unchanged. Read Core agent/RATES.md for fixed-window semantics and estimator requirements.

The second generated test exercises these actual modules with PostgreSQL, confirms selected fallback persistence through service reconstruction, verifies settled rate/capacity/allowance state and current route revocation. Its provider and health signals are fixtures; it is not a real-model failover or process-kill test. Optional retention cleanup remains a separate explicit host policy; it is not enabled by this starter.

The host can pass `runtimeLimits` to `openApplication` with positive integer `maxTurns`, `maxCalls`, `maxBatchCalls`, `modelTimeoutMs` and `taskTimeoutMs`. Unknown fields are rejected; identity, model resolution, storage and policy cannot be replaced through this limits object. Core validates its supported batch range (1–8). Defaults remain the existing Runtime defaults. Bound batches are persisted and checked by the same Runtime; dependent calls still wait for earlier results. The opt-in `core-real-continuity` example uses this template for a separately executed Task after Session closure.

The default tool scope includes Memory listing as well as exact-key reads. Agents can discover a user's current memory keys without relying on hard-coded keys known only to a fixture. Applications still choose their own allowed tools and resource policy.

The HTTP entry uses `http.mjs` to expose the Task controls actually registered by
the application alongside `agent.work` and the job's declared tools. This includes
state reads, clarification (`tasks.provide_input`) and original transition receipt
lookup (`tasks.control_result`), plus `tasks.list` when a persistent cursor key is
configured. The host still authenticates each request; Capability authorization
and Task ownership remain enforced. Keep a stable request key when supplying
clarification and query its original receipt after response loss.
# Optional working plans

Pass `enablePlans: true` to `openApplication` and include `tasks.plan.read` /
`tasks.plan.update` in the job and Task Tool scopes to allow plan operations.
Current Workspace-backed plans then enter each inference context automatically.
They survive app reconstruction but remain editable working claims; a completed
plan never substitutes for the application outcome verifier. Defaults are unchanged.
# Optional one-time scheduled work

Pass `scheduling: {restoreActor, isEnabled?}` to `openApplication`. `restoreActor`
resolves the saved scope into a currently authenticated application principal;
the app checks authorization and verifies that the resolved scope matches the
original owner. Add `assistant.schedule` and desired
`my_get_scheduled_assistant_task`, `my_list_scheduled_assistant_tasks`,
`my_cancel_scheduled_assistant_task`, `my_retry_scheduled_assistant_task` tools to
the job configuration and to the Task scope where needed.

`assistant.schedule` takes `{dueAt, task}` with an explicit timestamp and child
`allowedTools`. It returns a durable scheduled intent, not a completed Task. The
shared Core rules prevent recursive scheduling and preserve the parent's resource
limits when an Agent schedules work. Dispatch rechecks current authorization and
binds current model settings; actual inference still uses the user's current
platform allowance/BYOK rules. A closed Session does not cancel scheduled work.

Use `app.start()` to start the Runtime and optional scheduler, or call their
individual `tick()` methods from your own worker. `app.close()` drains the
scheduler before stopping Runtime. The generated server uses this lifecycle.
The template claims scheduled intents for its job ID only; the host's identity
restorer handles the permitted organizations for that job. Workers sharing this
table must use compatible claim scopes; an unfiltered legacy worker can still
claim any row. Runtime executor/version ownership rules are unchanged.

This opt-in wiring adds no recurring/event subscription configuration or new
scheduler engine. Those existing Core modules remain separate compositions.
Deployment, worker availability and current identity lookup remain host-owned.
# Optional event-driven work

Pass `eventWork: {sourceFor, buildTask}` together with the existing
`scheduling: {restoreActor}` queue/worker configuration. `sourceFor(actor)` assigns
trusted event provenance. `buildTask(actor,event)` is host code that creates a
bounded Agent input with explicit `allowedTools`; it must not treat event data
as permission. Include `my_read_assistant_event` in the job's Tool scope so the
Agent can read the pinned source. Event publishing is a host integration port,
not a newly exposed model Tool or unauthenticated webhook.

```js
await app.eventSubscriptions.subscribe(actor, {key: 'inbox', prefix: 'source:'});
await app.events.publish(actor, {key: 'source:stable-id', data: payload});
await app.eventTasks.tick(actor, {key: 'inbox', limit: 20});
```

Drive consumption from your existing listener/worker, including after restart;
`app.start()` runs deferred admission and Runtime, not a subscription scanner.
The returned `hasMore` and cursor support bounded continuation. Publishing alone
does not start inference. Consumption retains an original source/event-bound
queue intent before acknowledging the event. After a lost queue response,
reconstruction reuses that intent instead of calling buildTask again. Cursor
acknowledgement proves queuing, not successful business completion. Query the
linked deferred receipt/Task for current results.

Event and subscription stores use the same explicit Agent/user/application scope
as other job resources. Current authorization applies to publishing, consuming
and deferred dispatch; the Task source key restricts its event-read Tool. This
wiring uses existing Core modules and adds no broker, automatic polling policy,
provider-specific webhook adapter or universal business-effect deduplication.
The event Work option can use the queue without exposing `assistant.schedule`
to the job's models; one-time scheduling Tool access remains separately explicit.

# Optional standing authorization

Pass `mandates: {authorizeGrant, sourceFor}` to `openApplication`. The template
initializes the existing MandateStore and AssistantMandates with the same current
application/user/job scope as other resources, returns `app.mandates`, and connects
it to Task schemas and Runtime checks. Both trusted host ports are required.
`authorizeGrant(actor, terms)` must explicitly allow a grant; `sourceFor(actor)`
records its authorization source. These operations are host integration methods,
not model Tools or automatically published HTTP endpoints.

```js
const grant = await app.mandates.grant(actor, {
  requestKey: 'owner-approved-work-v1', capability: 'agent.work',
  tools: ['my_read_workspace'], purpose: 'Read my work materials',
  expiresAt: '2027-01-01T00:00:00Z',
});
await app.dispatcher.invoke('agent.work', {
  goal: 'Review the available work materials',
  allowedTools: ['my_read_workspace'], mandate: {id: grant.id},
}, {actor, callId: 'review-work-v1'});
```

The referenced grant survives reconstruction. Current permission, job Tool scope,
model allowance and outcome verification remain mandatory; a Mandate cannot
widen them. Purpose is explanatory text, not a semantic goal or data filter.
Tasks without a reference keep explicit per-request authorization. The option
creates no automatic grant, discovery/renewal policy or approval UI.

`app.mandates.revoke(actor, id)` permanently stops later execution using that
reference. Existing Task read/cancellation remain available; an already admitted
model request or external effect is still accountable. A scheduled Task carries
its reference and rechecks it at actual admission: an accepted queue receipt is
not proof the Mandate will remain valid when work starts. Configure the same
Mandate option on the worker after restart. Removing the option does not grant
permission to previously bound work.

# Application-owned business capabilities

Pass `extraCapabilities: [yourCapability, ...]` to `openApplication`, using existing
`defineCapability` contracts exported from your application's own domain modules.
Add their names to `job.configuration.tools` and to the individual Task's explicit
`allowedTools` where appropriate. The starter registers them through the same
`createAgentTaskCapabilities` composition, Dispatcher and HTTP discovery/execution.
Current application authorization, job scope and each Capability's own authorizer
all remain mandatory. A registered business write is not implicitly added to a
Task's permitted tools. No business schema is copied into Core.

```js
import {reserveInventory} from './domain/inventory.mjs';
const app = await openApplication({
  ...applicationOptions,
  extraCapabilities: [reserveInventory],
  verifyOutcome: verifyInventoryOutcome,
});
```

The application owns domain transactions, idempotency/reconciliation semantics,
source access, result verification and pool/service lifecycle. Declare a current
`revalidate` port when Agent history needs the result again; return independently
checkable business evidence. Capability schemas alone are not outcome verification.
Changing domain code requires a new host Runtime version/evaluated release binding:
include added executable files in the host revision hash. The default config hash
cannot discover arbitrary imported domain files or external service changes.

The generated test injects an application-owned PostgreSQL operation, checks its
own rule and identity denial, reconstructs the application after Task admission,
then verifies one domain effect, two fixture model calls and metering. HTTP exposes
the same declared Capability and enforces its authorizer. Removing it from job
scope prevents further calls even while the host registration remains available.

## Optional evaluated release binding

After the host loads and verifies an evaluated release's implementation and
configuration, pass its existing release service and immutable reference:

```js
const selected = await releases.resolve(actor, 'production');
// Load the checked implementation, job, model policy, Skills and Prompt first.
const app = await openApplication({
  ...options,
  version: selected.manifest.implementationRevision,
  releaseBinding: {
    releases,
    reference: selected,
    implementationRevision: selected.manifest.implementationRevision
  }
});
```

The template decorates its existing AgentRegistry identity with
ReleaseBoundAgentIdentity. Admission and later Runtime checks require the pinned
release to remain active; ordinary Agent scope, lifecycle and tool restrictions
still apply. A stop blocks new work and subsequent actions from an in-flight
model response. Admitted effects and usage retain their original receipts.

Channel changes select later work. They do not migrate existing Tasks, reload a
worker or modify a model in place. Construct an application with the checked
fallback implementation to admit new fallback work; retain or explicitly end old
Tasks under the existing version/reconciliation rules. The host owns release
registration/rollback authorization, checked resource loading and deployment.
Passing a matching revision string alone is not proof that the evaluated bytes
were loaded. No release-management Tool or UI is added to the Agent.
