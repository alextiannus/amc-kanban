import {defineCapability,CapabilityDispatcher,type Actor,type TaskReceipt,type ExecutionContext} from '@immedi/iaic-core/capabilities/index.js';
import {createCapabilityHttpHandler} from '@immedi/iaic-core/http/server.js';
import {CapabilityHttpClient,CapabilityHttpError} from '@immedi/iaic-core/http/client.js';
import {publicErrorFields,type CoreErrorFields} from '@immedi/iaic-core/capabilities/errors.js';
interface User extends Actor {organization: string}
type Input = {value: string};
type Output = {value: string};
type Contracts = {'records.write': {input: Input; output: Output}; 'agent.work': {input: {goal: string}; output: TaskReceipt}};
const actor:User={subjectId:'fixture',scopeId:'fixture-app',organization:'fixture-org'};
let writes=0,seen:ExecutionContext<User>|undefined;
const capability=defineCapability<Input,Output,User>({name:'records.write',description:'Typed synthetic write',input:{type:'object',properties:{value:{type:'string'}},required:['value'],additionalProperties:false},output:{type:'object',properties:{value:{type:'string'}},required:['value'],additionalProperties:false},effect:'write',retry:'idempotent',
 authorize:(a,input)=>a.organization==='fixture-org'&&input.value.length>0,
 preflight:input=>({valid:input.value!=='denied',feedback:'Use another fixture value'}),
 implementation:{kind:'function',execute:(input,context)=>{writes++;seen=context;return {value:input.value};}},
 revalidate:(_input,previous,{actor})=>actor.subjectId==='fixture'?previous:{value:'redacted'},
});
const work=defineCapability<{goal:string},{summary:string},User>({name:'agent.work',description:'Typed Agent admission',input:{type:'object',properties:{goal:{type:'string'}},required:['goal']},output:{type:'object',properties:{summary:{type:'string'}},required:['summary']},effect:'write',retry:'idempotent',authorize:a=>Boolean(a.scopeId),implementation:{kind:'agent',instructions:'Use the declared tools',tools:['records.write'],verify:(_input,result,{history})=>({verified:result.summary.length>0&&history.calls.length>0})}});
const dispatcher=new CapabilityDispatcher<Contracts,User>({capabilities:[capability,work],tasks:{create:async({actor,idempotencyKey})=>({id:'fixture-task',status:'queued',owner:actor.subjectId,requestKey:idempotencyKey})}});
const signal=new AbortController().signal;
const direct:Output=await dispatcher.invoke('records.write',{value:'direct'},{actor,callId:'direct',signal,allowedCapabilities:['records.write'],taskId:'00000000-0000-4000-8000-000000000001'});
if(direct.value!=='direct'||seen?.callId!=='direct'||seen?.taskId!=='00000000-0000-4000-8000-000000000001'||seen?.signal!==signal)throw Error('Typed context differs from runtime');
const handler=createCapabilityHttpHandler({dispatcher,resolveAccess:request=>request.headers.get('authorization')==='Bearer fixture'?{actor,capabilities:['records.write','agent.work']}:null});
const transport:typeof fetch=async(input,init)=>handler(new Request(input,init));
const client=new CapabilityHttpClient<Contracts>({url:'http://fixture/capabilities',fetch:transport,headers:()=>({authorization:'Bearer fixture'})});
const response=await client.invoke('records.write',{value:'http'},{requestKey:'http',signal});
if(response.resultKind!=='capability-result'||response.result.value!=='http')throw Error('HTTP contract differs');
const receipt=await dispatcher.invoke('agent.work',{goal:'fixture admission'},{actor,callId:'admission'});
if(receipt.status!=='queued'||receipt.owner!=='fixture')throw Error('Task admission contract differs');
try{await client.invoke('records.write',{value:'denied'},{requestKey:'denied'});throw Error('Expected preflight failure');}
catch(error){if(!(error instanceof CapabilityHttpError)||error.statusCode!==422||error.outcomeUnknown)throw error;}
const fields:CoreErrorFields={statusCode:409,publicCode:'FIXTURE_CONFLICT',outcomeUnknown:true};
if(publicErrorFields(fields).code!=='FIXTURE_CONFLICT'||writes!==2)throw Error('Error contract differs');

// Compile-only rejection checks; these must never execute.
if(false){
 // @ts-expect-error Invalid call context type.
 await dispatcher.invoke('records.write',{value:'x'},{actor,callId:7});
 // @ts-expect-error Allowed capabilities must be a list.
 await dispatcher.invoke('records.write',{value:'x'},{actor,allowedCapabilities:'records.write'});
 // @ts-expect-error Task ID is not a number.
 await dispatcher.invoke('records.write',{value:'x'},{actor,taskId:1});
 // @ts-expect-error Named contract rejects invalid input.
 await dispatcher.invoke('records.write',{value:3},{actor});
 // @ts-expect-error Wrong return type in a typed implementation.
 const bad:typeof capability.implementation={kind:'function',execute:()=>({value:3})};void bad;
 // @ts-expect-error Missing write retry contract.
 defineCapability({name:'bad.write',description:'bad',input:{},output:{},effect:'write',authorize:()=>true,implementation:{kind:'function',execute:()=>({})}});
 // @ts-expect-error HTTP access cannot omit actor identity.
 createCapabilityHttpHandler({dispatcher,resolveAccess:()=>({capabilities:[]})});
 // @ts-expect-error HTTP client rejects invalid named input.
 await client.invoke('records.write',{value:3});
}
console.log(JSON.stringify({typedCapabilityAndHttp:true,currentActor:true,callContext:true,taskAdmissionPort:true,preflightError:true,negativeCompileChecks:8,realAgentRuntime:false,rootTypes:false,peerTypes:false}));

// Public Lark entry must compile from the installed archive without an ambient shim.
import {larkMessage, createLarkNotificationDelivery} from '@immedi/iaic-core/channels/lark.js';
const incoming = larkMessage({header:{event_type:'im.message.receive_v1',event_id:'evt',app_id:'app',tenant_key:'tenant'},event:{sender:{sender_type:'user',sender_id:{open_id:'user'}},message:{chat_type:'p2p',chat_id:'chat',message_type:'text',content:'{"text":"hello"}'}}}, {installationId:'installation',appId:'app',tenantKey:'tenant'});
if (!incoming || incoming.provider !== 'lark' || incoming.text !== 'hello') throw Error('Lark normalization failed');
const delivery = createLarkNotificationDelivery({route:incoming,authorize:route=>route.senderId==='user',client:{im:{message:{create:async input=>({code:0,data:{chat_id:input.data.receive_id,message_id:'receipt'}})}}}});
const larkReceipt = await delivery.send({idempotencyKey:'stable-key',message:{text:'hello'}});
if (larkReceipt.status !== 'delivered' || larkReceipt.reference !== 'receipt') throw Error('Lark delivery failed');
if (false) {
 // @ts-expect-error Tenant binding is mandatory.
 larkMessage({}, {installationId:'installation',appId:'app'});
 // @ts-expect-error Outbound message text is a string.
 delivery.send({idempotencyKey:'key',message:{text:1}});
 // @ts-expect-error Unknown delivery does not have a confirmed provider receipt.
 const reference: string = ({} as Awaited<ReturnType<typeof delivery.send>>).reference;
}
console.log(JSON.stringify({larkTypedSubpath:true,larkRuntimeRoundTrip:true}));

import type {Client as OfficialLarkClient} from '@larksuiteoapi/node-sdk';
import type {LarkSdkClient} from '@immedi/iaic-core/channels/lark.js';
const officialSdkCompatible = (client: OfficialLarkClient): LarkSdkClient => client;
void officialSdkCompatible;

import {HostTaskContext,hostProjection} from '@immedi/iaic-core/context/host.js';
import type {HostBinding,CoreActor} from '@immedi/iaic-core/context/host.js';
type BusinessActor=CoreActor&{principalId:string};
let binding:HostBinding|null=null;
const host=new HostTaskContext<BusinessActor>({
 bind:async()=>({schema:'app.identity',version:'v1',reference:'original',revision:'1',projection:{principalId:'trusted'}}),
 resolve:async()=>({principalId:'trusted'}),authorize:()=>true,
 readTask:async(_actor,id)=>({id,trusted_context:binding}),
 restoreActor:async({actor})=>({...actor,principalId:'trusted'})
});
const owner={scopeId:'app',subjectId:'owner'};
binding=await host.bind({actor:owner,capability:{name:'agent.work'},idempotencyKey:'key',version:'v1'});
const projection=await host.project({actor:owner,task:{id:'task',trusted_context:binding}});
const restored:BusinessActor=await host.restoreActor({actor:owner,taskId:'task'});
if(projection.digest!==hostProjection({principalId:'trusted'}).digest||restored.principalId!=='trusted')throw Error('Host context typed consumer failed');
if(false){
 // @ts-expect-error Trusted context restoration requires a Task identity.
 host.restoreActor({actor:owner});
 // @ts-expect-error Core Actor always has a subject, independent of rich context.
 host.bind({actor:{scopeId:'app'},capability:{name:'agent.work'},idempotencyKey:'key',version:'v1'});
 // @ts-expect-error Projection binding is distinct from user-provided text.
 host.project({actor:owner,task:{id:'task',trusted_context:'forged'}});
}
console.log(JSON.stringify({hostContextTyped:true,hostActorExplicit:true,rootAmbientShim:false}));

// Consumption surface is a trusted constructor/call option, not business input.
const modelTools = dispatcher.toolsFor(actor, {surface:'model'});
void modelTools;
if(false){
 // @ts-expect-error Unknown surface is not accepted.
 dispatcher.toolsFor(actor, {surface:'untrusted'});
}
