# Platform Team host composition

## Start the minimum local host

Use Node 20 and a dedicated PostgreSQL database. Install the supplied Core archive
with `pg@8.23.0` and `@modelcontextprotocol/sdk@1.30.0`. Configure these environment
values in the local MCP client's process environment:

```sh
DATABASE_URL=postgresql://.../your_core_database
IAIC_PROVIDER=chat-completions
IAIC_MODEL=your-system-model
IAIC_MODEL_BASE_URL=https://your-model-gateway.example/v1
IAIC_MODEL_API_KEY=your-system-secret
PLATFORM_GRANT_ID=initial-platform-development
PLATFORM_GRANT_UNITS=1000000
```

Have the client launch:

```sh
node node_modules/@immedi/iaic-core/examples/core-platform-team/stdio.mjs
```

The process uses the existing MCP stdio transport; it opens no public HTTP port.
The launching operator controls its environment and credential access. The local
client is the configured external member, while the native worker uses a distinct
identity. Optional `PLATFORM_APPLICATION_ID`, `PLATFORM_TEAM_ID`,
`PLATFORM_NATIVE_ID` and `PLATFORM_EXTERNAL_ID` identify the host and participants.
This single-client entry is not a multi-user authentication product.

The deliberate grant ID is idempotent across restarts; changing the amount under
the same ID conflicts. A later top-up needs a new deliberate grant ID. Omit both
grant variables to start without funding. The default entry issues platform units
at one unit per metered input/output token, with a 100,000-unit inference hold;
these are allowance rules, not provider pricing. Customize policy through the
factory below. Its minimal verifier checks saved references and a successful work
operation; application-specific semantic correctness remains the injected verifier's
responsibility. The native Runtime permits at most four tool actions in a batch,
using existing ordering, authority and effect-receipt rules.

First create a shared artifact with `my_write_workspace`, then call
`platform.team.request` with a stable requestId and a goal referencing that artifact.
Poll `platform.team.request_result` or `platform.team.task` for the existing Task.
Read and record peer reviews through `collaboration.reviews.read/record`. Supply
the MCP envelope `{input: {...}, requestKey: "stable-operation-key"}` for writes.
The native worker runs in the same server process; restarting preserves stored
work. This is the phase-one local entry, not one of the phase-two Demo Projects.

`openPlatformTeam` in `application.mjs` assembles existing Core modules into a
headless host. It is application-owned composition, not a new Core Agent class or
Runtime. It does not create a User Assistant AI Demo.

The host requires a PostgreSQL pool, application/team identity, trusted built-in
actor, current `authorizeMember` policy, one system profile (`id: 'system'`), secret
resolver, platform-unit policy, independent outcome verifier, source version and
Skill/context root. Omit `modelFactory` to use the real ModelProfiles provider;
`run.mjs` alone injects a deterministic model. Keep credentials in the host secret
resolver. The service does not distribute system credentials or configure an
external member's inference account.

```js
const app = await openPlatformTeam({
  pool, applicationId, teamId, builtinActor, authorizeMember,
  profile: systemProfile, resolveSecret,
  tokenPolicy: platformDevelopmentUnitPolicy,
  verifyOutcome, version: implementationRevision, skillRoot,
  workCapabilities: existingAuthorizedDevelopmentCapabilities
});
// Host-only administrative funding; not exposed as a team tool.
await app.ledger.grant(app.budgetScope, {
  reference: fundingReference, amount: platformUnits, evidence: fundingEvidence
});
app.start();
// Expose app.dispatcher with the existing authenticated HTTP or MCP adapter.
// On shutdown: await app.close(); the host owns pool.end().
```

Both members use shared Workspace and peer-review tools under their own identity.
The shared workspace belongs to the team; revision provenance records its author.
The separate review-evidence workspace has no public direct write/delete tool.
Additional existing function capabilities can be supplied for repository work,
evaluation, execution, original-effect inspection, release or observation. They
retain their original authorization plus current team membership. Default tools
do not perform arbitrary host file edits or production deployments.

`platform.team.request({requestId,goal})` accepts work from either member and
creates a persistent native Task through the original Runtime. Its original
`requestedBy` comes from the authenticated caller, not a model field. Executor and
Agent identity remain the built-in Platform Agent. This is a request for platform
work under native platform authority, not a transfer of the requester's credentials
or a grant inheriting private user authority. Current team membership governs
admission and shared reads; native execution remains governed by native identity
and each tool's current policy. Removing a requester does not itself cancel work
already assigned to the platform; cancellation is a separate host Runtime action.

Retain requestId. It is scoped to application/team/requester and binds the original
goal through Runtime idempotency. Changed input under that ID conflicts; identical
retries recover the same Task. `platform.team.request_result({requestId})` recovers
your original request after a lost acknowledgement. Unknown is not permission to
resubmit with a new ID. `platform.team.task({id})` projects currently authorized
team Task state, requester, executor and result without model transcripts. There
is no new task table, ownership engine or shared login.

Task result sharing revalidates the original tool history under the reading
member's current authorization as well as the native executor's. Team membership
does not inherit private rights from the native executor's injected work tools.

The system model is metered against a fixed platform-development scope, separate
from personal-assistant scopes. The units are issued platform allowance, not raw
provider tokens or currency. An empty platform balance cannot borrow from a
funded personal allowance. Direct external reads, writes and reviews invoke no
hosted model; explicitly requesting native work consumes native platform units.
This host exposes neither user BYOK switching nor public allowance grants.

Every team member must update affected architecture, contracts, operation/recovery
instructions and version migration/lifetime documentation. Peer review and saved
plans are not proof of execution or release acceptance. The injected verifier
must check the application's actual outcomes and evidence.

Run `DATABASE_URL=<isolated PostgreSQL> node examples/core-platform-team/run.mjs`.
The installed example proves shared artifacts and reciprocal reviews, system
profile binding, requester/executor continuity across reconstruction, stable
requests and a separate platform budget: sixteen fixture inferences consume 112
platform units while the funded personal allowance remains unchanged. Both members
can originate requests. No real model, live Codex connection or paid inference is
used in this check. Persistent team-task takeover by the external member and
bidirectional interrupted-work continuation are still unfinished; this host does
not present native-only execution as the final team architecture.

## Real collaboration evidence and limits

On 2026-09-14 the system-model native member and current external Codex completed
a code-review/correction/follow-up loop on this host. Codex then recorded a
reciprocal review of the native-authored assessment through the same PeerReviews
service. STATUS.md records the exact Task and artifact digests, the rejected
incorrect initial findings and a retained unknown inference hold. The deterministic
example remains a separate reproducible check, not a simulation presented as that
real interaction.

The requester can continue its own Task through the MCP controls below. The native
member can control native-owned team Tasks. Other members can read shared results
but cannot cancel or answer work requested by a different member. Current team
membership is required. These adapters call the original Runtime under its native
execution identity; they do not transfer ownership or credentials.

- `platform.team.task({id})` returns `waitingReason` and the authorized
  `inputRequest` question/reference, in addition to the shared result.
- `platform.team.tasks.state({id})` reads lifecycle status without source history.
- `platform.team.tasks.provide_input({id,input})` answers a Task waiting for input.
- `platform.team.tasks.resume({id})` resumes eligible waiting work after the
  operator has funded the platform allowance or resolved its blocking condition.
- `platform.team.tasks.cancel({id})` cancels through the existing Runtime, even
  when historical sources are no longer accessible to the requester.
- `platform.team.tasks.control_result({id,requestKey})` reads the original resume
  or input receipt after a lost acknowledgement. Unknown is not permission to
  invent a new operation key.

For resume/input, supply a stable MCP envelope `requestKey` and retain it. Retrying
identical input under that key recovers the original receipt; changing input
conflicts. Reads and cancellations still require current requester authorization.
Neither these controls nor restarting the host grants extra allowance. Runtime
continues to enforce original versions, unresolved effects and eligible states.
A funded Task does not resume automatically; explicitly call resume. To continue
a Task from a replaced host version, run its original pinned archive/configuration
within its declared lifetime. A newer host does not reinterpret the old binding.
Shared work and review do not reassign a persistent native Task to Codex; arbitrary
interrupted-task takeover is deferred. Integrators explicitly supply authorized
development tools and outcome verification through the factory ports.

## Native Agent resources

The default stdio entry now gives the built-in Agent its own persistent Memory and
private Workspace, plus the bundled `platform-maintenance` Skill. This is resource
wiring on the existing Harness, not another Runtime or a User Assistant Demo.
`resources.mjs` owns the composition; the host reuses MemoryStore/AssistantMemory,
AssistantWorkspace and the existing resource Capability factory.

Native tools use `platform.self.` names. They include memory discovery/read/write,
revision-based correction/forgetting and import/export, private Workspace
list/read/write/delete, and `platform.self.assistant.skills.list/read`. The native
worker receives these tools by default, including memory writes. Memory is scoped
to application, team definition and native identity. Private Workspace uses the
same private scope; team Workspace and reserved review evidence remain separate.
Changing the model does not change resource ownership. Changing the native identity
selects different private storage, not a migration of the old identity's data.

The host factory accepts `skillEntries` relative to `skillRoot`. Its default empty
list means no installed Skills; the supplied stdio entry explicitly registers
`skills/platform-maintenance/SKILL.md`. Discovery puts selected Skill metadata in
the model context, and the Agent loads bodies/resources on demand through existing
Skill tools. Registered entries are checked at startup. The stdio version hashes
the resource composition and bundled Skill as well as host code. Custom hosts
must pin their selected Skill resources in their own version, as before. There is
no package auto-installation or inference of permissions from Skill metadata.

Memories are retrieved on demand, not copied wholesale into every model request.
The Agent is instructed to discover relevant notes, read exact keys, and save
reusable lessons as attributed, fallible notes. There is no automatic extraction,
semantic ranking or guarantee that every model chooses the best note. Context
limits use existing omission of old result bodies while retaining call receipts;
this is not semantic summarization or forgetting persistent memories.

Private tools are not exported to external MCP clients and reject external actors.
Task history and private storage are not returned by the shared Task view. Native
finish summaries, clarification questions and explicitly written shared artifacts
are deliberate team publications. The reader-side history check excludes these
known native-private tool calls, after native revalidation, while retaining current
reader checks on other injected work tools. This policy permits the native Agent
to use its own notes while producing team deliverables; it is not an automatic
information-flow classifier preventing an Agent from intentionally publishing
private content. Do not store system secrets in memories or publish them to peers.

Verification extends the existing composition: the model loads a Skill, writes its
own memory and private draft, waits, then reads both after host reconstruction.
A later Task reads the same note. External direct access is denied, the private
path is absent from team Workspace, and the intentionally shared result remains
readable without private tool history. This test uses a deterministic model.
