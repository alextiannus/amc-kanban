# Deferred tasks

A one-time durable intent submits to the existing Task Runtime at or after an explicit timestamp. This module owns only `iaic_deferred_tasks`; it provides no UI, calendar, notification flow or second Agent Runtime.

`DeferredTaskStore` owns scoped storage, immutable request replay, due claims and lease fencing. `DeferredTasks` exposes `schedule/get/list/cancel/retry`, plus `start/stop/tick` for the host worker. `deferredTools` adapts these methods to tools. Dependencies are a PostgreSQL pool and injected scope, actor restoration, input/access validation, idempotent task start and task lookup ports. The host defines the task schema and authorization. ImmediToday requires an explicit `allowedTools` list and uses current model/allowance settings when the task is created.

Schedule keys identify immutable timestamp/input pairs. Dispatch uses `deferred:<id>` as a stable Task request key. A lost start response is resolved through that key before attempting another start. The host must enforce idempotent start and compare recovered input; this worker is not a retry wrapper for arbitrary external writes. Only the current unexpired lease can admit or settle a claim.

States: queued → dispatching → dispatched, or retry → blocked after the configured attempt limit. `dispatched` proves a Task exists, not a completed outcome. Read and operate on the linked Task for progress, allowance pauses, results and cancellation after admission. Before admission, queued/retry/blocked intents can be cancelled. A dispatching claim cannot be cancelled concurrently. A blocked admitted intent with an uncertain receipt must be retried to recover its Task; cancellation does not pretend the start never occurred. Explicit retry preserves the original goal and key.

Restarted workers claim persisted due work and expired leases. A global pause prevents new dispatch; already admitted task creation can finish. There is no exact-time execution guarantee: service downtime, backlog and permission/model availability can delay work. Current authorization/schema is checked at dispatch. Ordinary code releases do not silently rewrite goals; incompatible input blocks. Existing task lifecycle rules govern a recovered Task.

This initial module does not implement recurring rules, external event subscriptions, expiry deadlines, full Agent work identity, or Session retention/automatic orphan repair. These remain separate capabilities. Focused tests: `test/iaic-deferred.integration.test.js`; independent package example: `examples/core-deferred`.

Optional injected `triggers.normalize/check` extends an intent with a condition, without introducing another dispatcher. The store owns nullable `trigger` and `trigger_receipt` fields. A pending check releases its lease and polls later without consuming attempts; a matched receipt is persisted at admission. See `../triggers/README.md` for the first task-completion implementation. A Task success receipt means the source Runtime accepted its configured verifier, not universal semantic truth.

A pre-existing Task is a recovery receipt only after this intent's durable admission. If a caller independently occupies the derived Task key before admission, the intent blocks instead of attributing that Task to its condition/time trigger. The independently created Task is preserved and remains governed by its own lifecycle.

The host must also reserve the `deferred:` Task key namespace against independent public callers; the admission guard alone is not a cross-system origin proof. ImmediToday rejects that prefix at public HTTP/MCP Assistant task creation and only its internal dispatcher can use it. This prevents a caller racing the intent's lookup/admission window. Direct trusted storage access remains a host responsibility.

Hosts can configure `reservedPrefixes` for internally composed intent keys. `schedule` rejects those keys unless its code-only third argument is `{internal:true}`. Never populate that option from public input. ImmediToday reserves `recurring:` and only its recurring worker uses the internal option. Fixed-interval recurring rules live separately in `../recurring`, leaving this module's one-time intent lifecycle unchanged.

Read/list results include the immutable requestKey so hosts can trace recurring occurrence keys through the public contract without querying private tables.

## Agent scheduling capability

`createDeferredScheduleCapability({deferred, taskSchema, authorize, name?})` exposes one-time scheduling through the existing dispatcher. The model supplies `{dueAt, task}`; trusted callId supplies `agent-call:<callId>`. Hosts must reserve that prefix on DeferredTasks and never expose its internal flag to callers. `findRequest(actor,key)` is a read-only receipt lookup; reconciliation compares the timestamp, exact task input and absence of a trigger. Missing receipt stays unconfirmed. History reads current intent state and linked Task ID. No new table or scheduler.

`createAgentTaskCapabilities({deferred,...})` registers `assistant.schedule` (with the configured namespace). It requires explicit parent allowedTools inclusion; it is not a default write. Future tools must narrow the parent scope; Session snapshot, source Event/Task and Mandate restrictions are preserved. The future schema excludes scheduling and delegation, preventing chains. Runtime passes current task alongside actor to allowCall; handoff-bound children cannot schedule independent work beyond their call/deadline budget. ImmediToday rejects the scheduling tool at child handoff admission as well. A host using the standalone capability must supply its own parent-scope policy.

An accepted schedule is independent durable work. Cancelling/completing the parent does not cancel the accepted intent. The owner uses existing scheduled-task get/cancel/retry interfaces and linked Task controls. Current permissions, model selection and platform allowance apply at future admission; the parent model pin does not pin the future Task. No calendar, recurring-chain, notification UI or automatic parent result waiting is implied. Tests: `iaic-assistant-scheduling.integration.test.js`, `iaic-schedule-scope.test.js`; independent example `core-deferred` also verifies the capability and receipt lookup.

`deferredControlTools` owns get/list/cancel/retry descriptors shared by owner adapters and `createDeferredControlCapabilities`. Agent composition includes reads by default; cancel/retry require explicit tool permission. Retry revalidates the stored future goal against the current parent tool and source/Mandate/Session ceilings, rejects scheduling/retry chains and is unavailable to handoff children. A cancelled-state receipt proves the desired cancellation state, not which caller caused it. A lost retry response remains unknown: current state alone cannot prove that particular retry call, so it is never automatically replayed or inferred from a later dispatch. Historical results read current intent state; already admitted tasks use their own controls. No new table, UI or scheduler.

Focused lifecycle regression: `test/iaic-schedule-controls.integration.test.js` exercises model-directed list/cancel/get and blocked-intent retry, scope rejection, future dispatch, current receipt refresh and post-admission cancellation refusal. Independent package example `core-deferred` also consumes get/cancel capabilities.
# Worker claim scope

`new DeferredTaskStore({pool, claimScope: {applicationId, assistantId}})` can limit
which intents a worker claims; either key may be omitted. The constructor copies
and freezes a nonempty filter. Filtering happens before `FOR UPDATE SKIP LOCKED`,
so foreign jobs are not claimed, retried or blocked by this worker. Omission
retains the previous unfiltered adapter behavior. This is worker routing, not
authorization: restored identity, current scope and input checks still apply.
All workers sharing a table must use compatible scopes; a legacy unfiltered
worker is not fenced by another worker's filter. No schema migration is required.
