# Persistent task module

Owns task state, persisted calls/events, transitions and its SQL migrations. Consumers provide a PostgreSQL pool and optionally `actorCodec` with `encode(actor) -> [scopeId, subjectId]` and `decode(pair) -> actor`. The default actor has `scopeId` and `subjectId`. Both identity components must be nonempty strings; actor decoding is used by Runtime before current capability authorization.

The two historical storage column names remain `employee_id` and `erp_user` so installed applications retain their existing tasks. Core treats them as opaque identity components; it does not contact ERP. ImmediToday's adapter is `src/ai-native/task-actor.js` outside this package.

Migrations are loaded relative to this module and included in the package. Do not read application-root SQL from Core. Read `store.js` and `migrations/` for task rules; focused checks are `test/iaic-tasks.integration.test.js` and `test/iaic-runtime.integration.test.js` with isolated PostgreSQL. Task version/reconciliation checks remain active; this change does not silently migrate old task code versions.


Tasks can carry an immutable `agent` identity snapshot. The trusted Runtime binding port supplies it, not the user task input. The Agent identity module owns live lifecycle data; Task storage does not join its tables. Legacy tasks remain null rather than receiving invented historical responsibility.

`createTaskReferenceCapability` composes injected current task/artifact read ports into a small read capability. It exposes status, original goal, error and still-accessible artifact references, omitting model transcripts and generated summaries. The application owns identity/authorization and must not return another principal's Task. Source completion triggers consume the same current view; no other module queries Task tables directly.

An optional trusted `handoff` snapshot binds a child to a contract owned by the Handoffs module. TaskStore persists the snapshot/event only; it does not read handoff tables. Runtime rejects execution when a bound child lacks its resolver. Legacy Tasks keep null bindings.

Explicit deterministic result waits are owned here: executor `settle(...,{wait:true})` records a successful read and waiting state in one transaction. `pendingResultWait(version,after)` projects only a latest result_wait event for a successful read. `wakeResultWait` is a trusted Runtime port; it checks identity, version, exact event/call identity, waiting state and absence of uncertain calls under the Task row lock before queuing the Task and recording result_ready/resumed. No caller should access the private task tables to implement polling. Manual/user-input transitions retain their existing behavior; stale wake receipts do not override them.

The optional immutable `delegation` intent uses additive migration012. Executor `delegate` atomically records one intent and external-result wait, rejecting nested/second delegation and unresolved calls. `pendingDelegation(version,after)` and trusted `receiveDelegation(actor,id,{version,delegationId,receipt})` are the observer ports. Receipt delivery checks current owner, wait, version and intent under the row lock, records one event and queues the original Task. The `received` marker is receipt delivery, not a second child lifecycle store. Manual resume cannot bypass a pending intent; cancellation remains available. The Handoffs module owns child contracts.

## Shared lifecycle capabilities

`createTaskControlCapabilities({runtime, authorize, namespace='tasks', project})` exposes `tasks.get`, `tasks.state`, `tasks.cancel`, `tasks.resume` and `tasks.provide_input`. Supply the existing Runtime's `get`, `state` and `transition` ports (or closures when assembling the dispatcher first). Input is `{id}`; `provide_input` also requires `input`, a nonempty clarification up to 8,000 characters. The original goal/tool authority remains unchanged. Runtime owns current Task access, eligible waiting states, version bindings, unresolved calls and child cancellation. No new Task table, state machine or worker is introduced.

The default public view includes only id, capability, status and waitingReason; `get` additionally includes the current authorized result. It excludes raw input, internal identity, model binding and transcripts. A trusted `project(task,{actor,operation})` may adapt this shape to an existing application. The Agent starter retains its previous row projection for compatibility; applications should choose what their external interfaces expose.

`state` deliberately avoids historical source loading. It permits lifecycle coordination and cancellation without granting access to source/result content. `get` still applies Runtime history checks. Current authorization applies through the shared dispatcher; injected Runtime ports must enforce their ordinary owner and Task capability checks.

Cancel is idempotent at the Task lifecycle level. Resume and clarification are `never-replay`: a lost acknowledgement may have committed the transition, so inspect current state before deciding what to do; this adapter does not add immutable per-request transition receipts. History revalidation of writes reads state and never resumes/cancels again or appends another clarification. A refreshed state is not an original-operation receipt.

The same definitions can be exposed through HTTP, the typed HTTP client and MCP. Bind `get`, `state` and `cancel` into A2A along with an application-owned list capability and public A2A projection. List filtering/pagination and product UI are separate; this module does not pretend that the store's latest-50 convenience list is a complete paginated search API. See `examples/core-agent-surfaces` for one persistent Task across five entries, clarification, reconstruction, verified completion and cancellation after historical-source revocation.

### Optional original transition receipts

Enable `receipts:true` and provide `runtime.transitionReceipt` to give `resume` and `provide_input` stable request semantics. Their shared Capability call ID becomes the transition request key, and these two capabilities advertise `idempotent`. The Agent starter enables this mode. Cancellation retains its existing behavior; its downstream child cancellation is not covered by these receipt transactions.

The Task store's additive migration015 owns an immutable receipt keyed by Task ID and request key. Action, original Runtime version and clarification content are bound by a digest. Under the same Task row lock and database transaction, it updates the Task, appends input/resume events and stores a small original outcome snapshot. Concurrent or repeated identical requests return that snapshot without transitioning again, including when the Task has since entered another wait. Changed action, version or content under the same key conflicts. Calls without a request key retain the previous transition API and rules.

`tasks.control_result({id,requestKey})` returns `status:'confirmed'` with the original action/digest/Task snapshot, or `status:'unknown'` when no receipt is available. It reads current Task authorization without requiring historical source access or an active release. A returned original `queued` snapshot does not mean the Task is still queued; query `tasks.state` separately. Missing evidence is not proof that a request cannot still commit. Do not switch to a new key merely to evade uncertainty.

A prior receipt can be returned before new-execution checks because doing so does not repeat the transition. A new transition still checks current Runtime execution eligibility, version, waiting reason and uncertain calls. Current owner/Task capability authorization applies both to receipt queries and to retries. These receipts cover the accepted lifecycle mutation, not subsequent inference, tool effects, completion or child cancellation. They do not identify which human clarification is intended for a new wait; applications must use a fresh deliberate request for new input.

Recorded control history refresh reads the original receipt rather than re-executing the control. Existing `receipts:false` compositions keep metadata-only current-state refresh and never-replay resume/input behavior. The host projection receives a compact transition snapshot in receipt mode, not a raw complete Task row.

## Current-authorized Task discovery

`TaskListing({store, readTask, resolveOwner, cursorKey, project})` adds bounded Task discovery without a new Runtime or direct cross-module table access. The default TaskStore `page` port owns descending `(created_at,id)` keyset queries and preserves PostgreSQL microseconds in internal positions; the old latest-50 `list` convenience method remains unchanged. Migration016 adds the owner/order index.

Use `readTask:(actor,id)=>runtime.state(actor,id)` for current authorization without historical source/result access. `resolveOwner` returns a stable host identity string for the caller's Task scope. Supply a dedicated persistent 32-byte `cursorKey`; keep it across service reconstruction. The encrypted/authenticated cursor binds owner and capability/status filters and hides internal positions of denied Tasks. Rotating the key invalidates old cursors; start a new listing. Fixture keys in examples are for deterministic local tests only.

`listing.list(actor,{limit=20,cursor,capability,status})` scans at most 100 candidates and returns `{items,nextCursor}`. It omits Tasks currently denied or missing, rechecks requested status/capability after the read, and propagates other service failures. A page can be empty with a non-null nextCursor: continue to advance. Default items contain only id, capability, status and waitingReason; trusted `project` can adapt them. This is a live listing, not a database snapshot, total count, event queue or exactly-once export. New/backdated commits and changing status/permissions may affect later pages; refresh from the beginning when current completeness matters.

`createTaskListCapability({listing,authorize,name='tasks.list'})` exposes the same contract through the dispatcher and refreshes history through current reads. The Agent starter accepts optional `taskCursorKey` to enable this capability and returns its taskListing service. Existing hosts without a key preserve their current capability set. Public A2A pageSize/pageToken and filters remain explicit host bindings; the installed surface example carries a SDK cursor into an A2A next-page request for the same capability filter, with no separate listing store.

## Display the current input request

`AgentRuntime.get` and the default `tasks.get` projection now include `inputRequest`, either null or `{question,reference}` for a Task currently waiting for input. The question and reference come from its latest persisted model wait response; no question is inferred for other wait states. Queued, completed and cancelled Tasks return null. Runtime's existing current history authorization/revalidation runs before returning this model-generated content. `tasks.state` stays metadata-only so lifecycle coordination does not require source content access.

The reference identifies the recorded response; it is not a conditional-write token or an authorization grant. Use the existing stable clarification request key and receipt rules. Applications own stale-question interaction, display and any additional output/retention policy; this field does not reconstruct a new question or automatically redact derived historical statements. See the opt-in core-ui-bindings example for a browser using this field through the ordinary SDK.

Model waits additionally expose an allow-listed diagnostic in default controls/listing. Deterministic model failures cannot be resumed. See [model failures and migration](../agent/MODEL_FAILURES.md).

Migration017 and host-only executorState/requestExecutorDrain ports support generation-scoped handoff; all executor transactions validate ownership. See [deployment contract](../agent/EXECUTOR_HANDOFF.md).
