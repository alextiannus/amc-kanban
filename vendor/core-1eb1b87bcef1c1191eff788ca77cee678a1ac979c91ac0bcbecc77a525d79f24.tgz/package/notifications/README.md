# Durable notifications

This independent module provides a persistent outgoing queue, delivery attempts and shared Capability operations. Applications supply channels and recipient resolution; no email, SMS, chat provider, business template or UI is prescribed. The default implementation is a PostgreSQL outbox, not a bundled SMTP service or a user inbox.

`PostgresNotificationStore({pool,namespace})` owns queue/attempt tables. `Notifications({store,resolveScope,authorize,resolveDelivery})` provides enqueue, get, history, cancel, retry, reconcile and a worker `tick({leaseSeconds?,signal?})`. Storage is an injectable port; alternate adapters must preserve scope isolation, stable-key binding, exclusive claims, attempt fencing, history and unknown outcomes.

`enqueue(actor,{requestKey,recipientId,channel,message,source?})` binds content to a stable key within the actor's host-resolved scope. Repeated identical content returns the original record; changed content conflicts. The response proves queue admission, not delivery. Recipient/channel are logical references: `resolveDelivery(job)` rechecks current permission and resolves actual destination and credentials when executing. Do not copy credentials into message, source or durable actor data. Host authorization decides who may notify whom and who may inspect receipts.

`resolveDelivery` returns `{allowed:true,send,query?}`. Its closure owns the channel connection and destination. `send({idempotencyKey,message,source,signal})` and optional `query({idempotencyKey})` return `{status:'delivered'|'not_sent'|'unknown', ...receipt}`. The stable key is the queue record ID across attempts. `delivered` denotes the adapter's explicitly defined milestone (for example provider acceptance); it does not claim human reading. `not_sent` must prove definitive non-delivery with no outstanding operation that could still send. A missing receipt or ordinary provider "not found yet" is unknown, not this proof. Core cannot manufacture exactly-once delivery from a non-idempotent channel.

The host schedules `tick` calls and manages shutdown/transport deadlines. One pending item is exclusively claimed per tick. No model is invoked. An exception after entering send is unknown. Expired sending leases also become unknown, never automatically pending. A worker checks its current claim before entering send, but a database lease cannot fence an already issued external effect; channel semantics and reconciliation remain authoritative. Aborting the signal does not undo a send.

Unknown notifications require authorized query/reconciliation. Only a definitive `not_sent` failure permits explicit retry; current delivery permission is rechecked on the next attempt. Pending items may be cancelled. Sending, unknown or delivered effects cannot be reversed through cancellation. Attempts are retained across retry and current terminal results cannot be overwritten by stale attempt tokens.

`createNotificationCapabilities({notifications,prefix?})` exposes six operations through the existing Dispatcher/HTTP/MCP/Runtime. Read/get and history are revalidated when reused in context. Enqueue is idempotent by requestKey; retry/cancel/reconcile are never-replay mutations. Receipts and history are scoped internal evidence and may contain channel references; expose only authorized projections in application UI.

Events, Tasks and subscriptions can enqueue notifications through the same service. `source` is caller-provided metadata, not automatically a verified business fact or authority grant. Hosts should verify and construct authoritative Event/Task references when required. `examples/core-notifications` composes an existing immutable event with this queue and a fixture channel; it sends no external messages. A default JSON HTTP channel adapter is now available; see HTTP.md. Provider-specific channel bindings, automatic event routing, templates/preferences, recipient inbox UI and retention remain integrations or later capabilities.


Optional [durable Task wake](./TASK_WAKE.md) composes this queue with Host Task
admission, original-receipt lookup and application Context-link repair. It uses
separate authorization for fresh admission and historical recovery, with explicit
channel/topic ownership. Inbox remains a separate recipient read model.
